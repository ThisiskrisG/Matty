let AUDIT_CSV_AUTO_DONE = false;

let API_BASE = "";

function log(msg){
  const box = document.getElementById("log");
  if (!box) return;
  const p = document.createElement("div");
  p.className = "log-line";
  const now = new Date().toLocaleTimeString();
  p.textContent = `[${now}] ${msg}`;
  box.prepend(p);
}

function resolveUrl(path){
  if (!API_BASE) return path;
  return API_BASE.replace(/\/$/, "") + path;
}

function safeFetch(path, options){
  return fetch(resolveUrl(path), options);
}

function saveApiBase(){
  const input = document.getElementById("api-base");
  const val = input.value.trim();
  API_BASE = val || "";
  if (API_BASE){
    localStorage.setItem("arena_api_base", API_BASE);
    log("API base set to " + API_BASE);
  } else {
    localStorage.removeItem("arena_api_base");
    log("API base cleared, using relative URLs.");
  }
  refreshAll();
  setInterval(loadTipStream,3000);
  document.getElementById("tp-send").addEventListener("click", sendTip);
  document.getElementById("tp-close").addEventListener("click", closeTipPopup);
  attachTipPresets();
  setTimeout(attachMiniProfileEvents,500);
}

function loadApiBase(){
  const saved = localStorage.getItem("arena_api_base");
  if (saved){
    API_BASE = saved;
    const input = document.getElementById("api-base");
    if (input) input.value = saved;
  }
}

function refreshAll(){
  loadLeaderboardStats();
  loadDaily();
  loadCharts();
  loadBTC();
  loadBTCTodayYesterday();
  loadTopStreaks();
  loadBattleUsers();
  loadTipStream();
  loadMe();
}

// ---------------- Top stats cards ----------------
function loadLeaderboardStats(){
  safeFetch("/api/leaderboard")
    .then(r => r.json())
    .then(data => {
      const players = Array.isArray(data) ? data : [];
      document.getElementById("stat-players").textContent = players.length;

      // If we wanted global coin sum:
      // const totalCoins = players.reduce((sum,p)=>sum + (p.coins || 0),0);
    })
    .catch(err => {
      log("Error loading leaderboard: " + err);
      document.getElementById("stat-players").textContent = "--";
    });
}

function loadDaily(){
  safeFetch("/api/arena/daily")
    .then(r => r.json())
    .then(data => {
      document.getElementById("stat-daily-mode").textContent = data.mode || "--";
      const reward = `Reward: 🪙 ${data.reward_coins || 0} • ⚡ ${data.reward_xp || 0} XP`;
      document.getElementById("stat-daily-reward").textContent = reward;
    })
    .catch(err => {
      log("Error loading daily: " + err);
      document.getElementById("stat-daily-mode").textContent = "--";
      document.getElementById("stat-daily-reward").textContent = "Reward: --";
    });
}

// ---------------- Charts ----------------
let chartCoins, chartElo, chartBTC;

function loadCharts(){
  safeFetch("/api/leaderboard")
    .then(r => r.json())
    .then(data => {
      const list = Array.isArray(data) ? data.slice(0,10) : [];
      const labels = list.map(p => p.username);
      const coins = list.map(p => p.coins || 0);
      const elos = list.map(p => p.elo || 0);

      // Coins chart
      const ctx1 = document.getElementById("chart-coins").getContext("2d");
      if (chartCoins) chartCoins.destroy();
      chartCoins = new Chart(ctx1, {
        type: "bar",
        data: {
          labels,
          datasets: [{
            label: "Coins",
            data: coins
          }]
        },
        options: {
          responsive: true,
          plugins: { legend: { display: false } },
          scales: {
            x: { ticks: { color: "#9ca3af" } },
            y: { ticks: { color: "#9ca3af" } }
          }
        }
      });

      // ELO chart
      const ctx2 = document.getElementById("chart-elo").getContext("2d");
      if (chartElo) chartElo.destroy();
      chartElo = new Chart(ctx2, {
        type: "line",
        data: {
          labels,
          datasets: [{
            label: "ELO",
            data: elos,
            tension: 0.3,
            fill: false
          }]
        },
        options: {
          responsive: true,
          plugins: { legend: { display: false } },
          scales: {
            x: { ticks: { color: "#9ca3af" } },
            y: { ticks: { color: "#9ca3af" } }
          }
        }
      });
    })
    .catch(err => {
      log("Error loading charts from leaderboard: " + err);
    });

  // BTC chart
  safeFetch("/api/arena/tip_leaderboard")
    .then(r => r.json())
    .then(data => {
      const list = Array.isArray(data) ? data.slice(0,10) : [];
      const labels = list.map(p => p.username);
      const btcTotals = list.map(p => p.btc_total || 0);

      const ctx3 = document.getElementById("chart-btc").getContext("2d");
      if (chartBTC) chartBTC.destroy();
      chartBTC = new Chart(ctx3, {
        type: "bar",
        data: {
          labels,
          datasets: [{
            label: "Total BTC",
            data: btcTotals
          }]
        },
        options: {
          responsive: true,
          plugins: { legend: { display: false } },
          scales: {
            x: { ticks: { color: "#9ca3af" } },
            y: { ticks: { color: "#9ca3af" } }
          }
        }
      });
    })
    .catch(err => {
      log("Error loading BTC chart: " + err);
    });
}

// ---------------- BTC tables + stats ----------------
function loadBTC(){
  safeFetch("/api/arena/tip_leaderboard")
    .then(r => r.json())
    .then(list => {
      const rows = Array.isArray(list) ? list : [];

      document.getElementById("stat-btc-creators").textContent = rows.length;

      const totalBtc = rows.reduce((sum, row) => sum + (row.btc_total || 0), 0);
      document.getElementById("stat-btc-total").textContent = totalBtc.toFixed(6);

      const wrap = document.getElementById("table-btc");
      if (!wrap) return;
      if (!rows.length){
        wrap.innerHTML = '<div class="muted">No BTC tips yet.</div>';
        return;
      }

      let html = '<table class="btc-table"><thead><tr>' +
        '<th>#</th><th>User</th><th>Total BTC</th><th>Biggest Tip</th><th>Count</th>' +
        '</tr></thead><tbody>';

      rows.forEach(row => {
        html += `<tr>
          <td>${row.rank}</td>
          <td>${row.username}</td>
          <td>${(row.btc_total || 0).toFixed ? row.btc_total.toFixed(6) : row.btc_total}</td>
          <td>${(row.btc_biggest || 0).toFixed ? row.btc_biggest.toFixed(6) : row.btc_biggest}</td>
          <td>${row.btc_count || 0}</td>
        </tr>`;
      });

      html += '</tbody></table>';
      wrap.innerHTML = html;
    })
    .catch(err => {
      log("Error loading BTC leaderboard table: " + err);
      document.getElementById("stat-btc-creators").textContent = "--";
      document.getElementById("stat-btc-total").textContent = "--";
      const wrap = document.getElementById("table-btc");
      if (wrap) wrap.innerHTML = '<div class="muted">BTC leaderboard API not reachable.</div>';
    });
}

// ---------------- Me card ----------------
function loadMe(){
  const card = document.getElementById("card-me");
  if (!card) return;

  safeFetch("/api/arena/stats/me")
    .then(r => {
      if (r.status === 401){
        card.innerHTML = '<p class="muted">Not logged in. Log in to Matty in this browser then click “Connect”.</p>';
        throw new Error("unauthorized");
      }
      return r.json();
    })
    .then(data => {
      if (data.error){
        card.innerHTML = '<p class="muted">Could not load Arena stats for current user.</p>';
        return;
      }

      const avatar = data.avatar || "/static/default-avatar.png";
      const name = data.username || "Unknown";

      card.innerHTML = `
        <div class="me-main">
          <img class="me-avatar" src="${avatar}" alt="${name}" />
          <div>
            <div class="me-name">${name}</div>
            <div class="muted">Live stats for your arena profile.</div>
          </div>
        </div>
        <div class="me-fields">
          <div>🪙 Coins: <b>${data.coins}</b></div>
          <div>⚡ XP: <b>${data.xp}</b></div>
          <div>🎖 Level: <b>${data.level}</b></div>
          <div>📈 ELO: <b>${data.elo}</b> (${data.tier})</div>
          <div>₿ Total BTC: <b>${data.tip_btc_total}</b></div>
          <div>🔥 Streak: <b>${data.tip_streak_days}</b> days</div>
        </div>
      `;
    })
    .catch(err => {
      log("Error loading /api/arena/stats/me: " + err);
      if (err.message !== "unauthorized"){
        card.innerHTML = '<p class="muted">Stats API not reachable. Check backend.</p>';
      }
    });
}


function loadBTCTodayYesterday(){
  safeFetch("/api/arena/btc/today_yesterday")
    .then(r => r.json())
    .then(data => {
      const today = data.today || 0;
      const yesterday = data.yesterday || 0;

      document.getElementById("stat-btc-compare").textContent = today.toFixed(6);

      let diff = today - yesterday;
      let percent = yesterday > 0 ? (diff / yesterday) * 100 : 0;
      percent = percent.toFixed(1);

      const diffEl = document.getElementById("stat-btc-diff");
      if (diff > 0) {
        diffEl.innerHTML = `<span style="color:#22c55e;">🔼 +${percent}% vs yesterday</span>`;
      } else if (diff < 0) {
        diffEl.innerHTML = `<span style="color:#ef4444;">🔽 ${percent}% vs yesterday</span>`;
      } else {
        diffEl.innerHTML = `<span style="color:#9ca3af;">➖ No change</span>`;
      }

      const ctx = document.getElementById("chart-btc-compare").getContext("2d");
      if (window.chartBTCCompare) window.chartBTCCompare.destroy();

      window.chartBTCCompare = new Chart(ctx, {
        type: "bar",
        data: {
          labels: ["Yesterday", "Today"],
          datasets: [{
            label: "BTC",
            data: [yesterday, today],
            backgroundColor: [
              "rgba(255,180,80,0.7)",
              "rgba(255,220,90,0.9)"
            ]
          }]
        },
        options: {
          responsive: true,
          plugins: { legend: { display: false } },
          scales: {
            x: { ticks: { color: "#9ca3af" } },
            y: { ticks: { color: "#9ca3af" } }
          }
        }
      });

    })
    .catch(err => {
      log("Error loading BTC today/yesterday: " + err);
    });
}



function loadTopStreaks(){
  safeFetch("/api/arena/top_streaks")
    .then(r => r.json())
    .then(rows => {
      const wrap = document.getElementById("table-streaks");
      if (!wrap) return;

      if (!rows.length){
        wrap.innerHTML = '<div class="muted">No active BTC streaks yet.</div>';
        return;
      }

      let html = '<table class="btc-table"><thead><tr>' +
        '<th>#</th><th>User</th><th>Streak</th><th>Total BTC</th><th>Biggest</th>' +
        '</tr></thead><tbody>';

      rows.forEach(r => {
        html += `<tr>
          <td>${r.rank}</td>
          <td>${r.username}</td>
          <td>${r.streak_days} days</td>
          <td>${r.total_btc}</td>
          <td>${r.biggest}</td>
        </tr>`;
      });

      html += '</tbody></table>';
      wrap.innerHTML = html;
    })
    .catch(err => {
      log("Error loading top streaks: " + err);
      const wrap = document.getElementById("table-streaks");
      if (wrap) wrap.innerHTML = '<div class="muted">Streak API not reachable.</div>';
    });
}



function loadBattleUsers(){
  // use leaderboard as pool of contenders
  safeFetch("/api/leaderboard")
    .then(r => r.json())
    .then(rows => {
      const list = Array.isArray(rows) ? rows : [];
      const a = document.getElementById("battle-user-a");
      const b = document.getElementById("battle-user-b");
      if (!a || !b) return;

      a.innerHTML = "";
      b.innerHTML = "";

      list.forEach(user => {
        const opt1 = document.createElement("option");
        const opt2 = document.createElement("option");
        opt1.value = user.id;
        opt2.value = user.id;
        opt1.textContent = user.username;
        opt2.textContent = user.username;
        a.appendChild(opt1);
        b.appendChild(opt2);
      });
    })
    .catch(err => {
      log("Error loading battle users from leaderboard: " + err);
    });
}

function runBattle(){
  const aSel = document.getElementById("battle-user-a");
  const bSel = document.getElementById("battle-user-b");
  if (!aSel || !bSel) return;

  const id1 = aSel.value;
  const id2 = bSel.value;

  if (!id1 || !id2){
    log("Select two users for battle.");
    return;
  }
  if (id1 === id2){
    log("Cannot battle same user.");
    return;
  }

  safeFetch(`/api/arena/battle/${id1}/${id2}`)
    .then(r => r.json())
    .then(data => {
      const A = data.a;
      const B = data.b;
      if (!A || !B){
        log("Battle API did not return both players.");
        return;
      }

      const box = document.getElementById("battle-results");
      if (!box) return;

      box.innerHTML = `
        <div><b>${A.username}</b> • BTC: ${A.btc_total} • Streak: ${A.streak} days • ELO: ${A.elo}</div>
        <div><b>${B.username}</b> • BTC: ${B.btc_total} • Streak: ${B.streak} days • ELO: ${B.elo}</div>
      `;

      if (A.btc_total > B.btc_total){
        box.innerHTML += `<div style="color:#22c55e;margin-top:4px;">Winner (BTC): ${A.username}</div>`;
      } else if (A.btc_total < B.btc_total){
        box.innerHTML += `<div style="color:#22c55e;margin-top:4px;">Winner (BTC): ${B.username}</div>`;
      } else {
        box.innerHTML += `<div style="color:#9ca3af;margin-top:4px;">BTC: Tie</div>`;
      }

      const ctx = document.getElementById("battle-chart").getContext("2d");
      if (window.battleChart) window.battleChart.destroy();

      window.battleChart = new Chart(ctx, {
        type: "bar",
        data: {
          labels: [A.username, B.username],
          datasets: [{
            label: "Total BTC",
            data: [A.btc_total, B.btc_total]
          }]
        },
        options: {
          responsive: true,
          plugins: { legend: { display: false } },
          scales: {
            x: { ticks: { color: "#9ca3af" } },
            y: { ticks: { color: "#9ca3af" } }
          }
        }
      });
    })
    .catch(err => {
      log("Error running battle: " + err);
    });
}



let lastTipId = null;

function loadTipStream(){
  safeFetch("/api/arena/tip_stream")
    .then(r => r.json())
    .then(rows => {
      const box = document.getElementById("tip-stream-list");
      if (!box) return;

      if (!rows.length){
        box.innerHTML='<div class="muted">No tips yet.</div>';
        return;
      }

      if (lastTipId === rows[0].id) return;
      lastTipId = rows[0].id;

      box.innerHTML = "";
      rows.forEach(tip => {
        const div = document.createElement("div");
        div.className="tip-entry";
        div.innerHTML=`
          <b>${tip.amount.toFixed(6)} BTC</b>
          from <span style="color:#e0e7ff">${tip.sender}</span>
          to <span style="color:#86efac">${tip.receiver}</span>
          <div class="muted" style="font-size:11px;">${new Date(tip.created_at).toLocaleTimeString()}</div>
        `;
        box.appendChild(div);
      });
    })
    .catch(err => log("Tip stream error: "+err));
}



let miniTimeout = null;

function showMiniProfile(userId, x, y){
  clearTimeout(miniTimeout);

  safeFetch(`/api/arena/profile_mini/${userId}`)
    .then(r => r.json())
    .then(data => {
      const box = document.getElementById("mini-profile");
      if (!box) return;

      if (data.error){
        box.classList.add("hidden");
        return;
      }

      box.innerHTML = `
        <img src="${data.avatar}">
        <div class="mp-name">${data.username}</div>

        <div class="mp-field">Level ${data.level} • ${data.xp} XP</div>
        <div class="mp-field">ELO: ${data.elo} (${data.tier})</div>
        <div class="mp-field">Coins: ${data.coins}</div>

        <div class="mp-field">BTC: ${data.btc_total}</div>
        <div class="mp-field">Biggest: ${data.btc_biggest}</div>
        <div class="mp-field">Streak: ${data.streak} days</div>

        <button onclick="selectBattle('${data.id}')">Battle</button>
      `;

      box.style.left = x + 15 + "px";
      box.style.top = y + 15 + "px";

      box.classList.remove("hidden");
    })
    .catch(err => console.log("mini profile error", err));
}

function hideMiniProfile(){
  const box = document.getElementById("mini-profile");
  if (!box) return;
  box.classList.add("hidden");
}

function attachMiniProfileEvents(){
  document.querySelectorAll("[data-user]").forEach(el => {
    el.addEventListener("mouseenter", (e)=>{
      const id = el.getAttribute("data-user");
      showMiniProfile(id, e.clientX, e.clientY);
    });
    el.addEventListener("mouseleave", hideMiniProfile);
  });
}

function selectBattle(id){
  const a = document.getElementById("battle-user-a");
  const b = document.getElementById("battle-user-b");

  if (a.value === b.value){
    a.value = id;
  } else if (a.value === id){
    a.value = id;
  } else {
    b.value = id;
  }
}



function openTipPopup(id, name){
  const popup = document.getElementById("tip-popup");
  document.getElementById("tp-user").textContent = `Tip to: ${name}`;
  popup.dataset.userid = id;
  popup.classList.remove("hidden");
  loadTierPresets(id);
}

function closeTipPopup(){
  document.getElementById("tip-popup").classList.add("hidden");
}

function sendTip(){
  const popup = document.getElementById("tip-popup");
  const id = popup.dataset.userid;
  const amount = parseFloat(document.getElementById("tp-amount").value);

  if (!amount || amount <= 0){
    log("Invalid BTC amount.");
    return;
  }

  safeFetch("/send_tip", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({
      receiver_id: id,
      amount_btc: amount
    })
  })
  .then(r => r.json())
  .then(res => {
    log("Tip sent: " + amount + " BTC to " + id);
    playTipAnimation(amount);
    closeTipPopup();
    const pop = document.getElementById("tip-popup");
    if(pop){ pop.style.boxShadow = "0 0 25px #facc15"; setTimeout(()=>{ pop.style.boxShadow="none"; }, 300); }

    // Refresh key data sections
    loadTipStream();
    loadBTC();
    loadTopStreaks();
    loadBTCTodayYesterday();
  });
}



function attachTipPresets(){
  document.querySelectorAll(".preset-btn").forEach(btn=>{
    btn.addEventListener("click", ()=>{
      const val = btn.dataset.val;
      if (val){
        document.getElementById("tp-amount").value = val;
      }
    });
  });

  const maxBtn = document.getElementById("tp-max");
  if (maxBtn){
    maxBtn.addEventListener("click", ()=>{
      // future: detect real user balance
      document.getElementById("tp-amount").value = "0.05";
    });
  }
}



function loadTierPresets(userId){
  safeFetch(`/api/arena/tip_presets/${userId}`)
    .then(r => r.json())
    .then(data => {
      const box = document.getElementById("tp-preset-box");
      box.innerHTML = "";

      data.presets.forEach(val => {
        const b = document.createElement("button");
        b.className = "preset-btn tier-" + data.tier.toLowerCase();
        b.textContent = val;
        b.dataset.val = val;
        b.addEventListener("click", ()=>{
          document.getElementById("tp-amount").value = val;
        });
        box.appendChild(b);
      });

      // Diamond tier gets MAX
      if (data.tier === "DIAMOND"){
        const maxbtn = document.createElement("button");
        maxbtn.className = "preset-btn tier-diamond";
        maxbtn.textContent = "MAX";
        maxbtn.addEventListener("click", ()=>{
          document.getElementById("tp-amount").value = "0.1";
        });
        box.appendChild(maxbtn);
      }
    });
}



function playTipAnimation(amount){
  const container = document.getElementById("tip-animations");
  if (!container) return;

  for(let i=0; i<4; i++){
    const coin = document.createElement("img");
    coin.src = "https://cryptologos.cc/logos/bitcoin-btc-logo.png";
    coin.className = "tip-coin";
    coin.style.left = (window.innerWidth/2 - 50 + Math.random()*100) + "px";
    coin.style.top = (window.innerHeight/2 - 30) + "px";
    container.appendChild(coin);
    setTimeout(()=>coin.remove(), 1200);
  }

  for (let i=0; i<14; i++){
    const spark = document.createElement("div");
    spark.className = "spark";
    spark.style.left = (window.innerWidth/2) + "px";
    spark.style.top = (window.innerHeight/2) + "px";
    const angle = Math.random() * Math.PI * 2;
    const dist = 60 + Math.random()*40;
    spark.style.setProperty("--dx", `${Math.cos(angle)*dist}px`);
    spark.style.setProperty("--dy", `${Math.sin(angle)*dist}px`);
    container.appendChild(spark);
    setTimeout(()=>spark.remove(),600);
  }

  const txt = document.createElement("div");
  txt.className = "tip-text-float";
  txt.innerHTML = `+${amount} BTC`;
  txt.style.left = (window.innerWidth/2 - 50) + "px";
  txt.style.top = (window.innerHeight/2 - 20) + "px";
  container.appendChild(txt);
  setTimeout(()=>txt.remove(),1300);
}



// --- ADMIN GATE ---
let ADMIN_TOKEN = localStorage.getItem("ADMIN_TOKEN");
if(!ADMIN_TOKEN){
    window.location.href = "admin-login.html";
}

// Override safeFetch to always include admin token
const _orig_safeFetch = safeFetch;
safeFetch = function(url, options = {}){
    options.headers = options.headers || {};
    options.headers["X-Admin-Token"] = ADMIN_TOKEN;
    return _orig_safeFetch(url, options);
};



function loadAuditLogs(){
  const box = document.getElementById('audit-log-list');
  if (!box) return;
  safeFetch('/api/admin/audit_logs')
    .then(r => r.json())
    .then(logs => {
      box.innerHTML = "";
      if (!Array.isArray(logs) || !logs.length){
        box.innerHTML = '<div class="muted">No audit logs yet.</div>';
        return;
      }
      logs.forEach(l => {
        const div = document.createElement("div");
        div.className = "audit-entry";
        div.innerHTML = `
          <strong>${l.action}</strong><br>
          <small>${l.details || ''}</small><br>
          <small>Admin ID: ${l.admin_id} | IP: ${l.ip || '-'}</small><br>
          <small>${new Date(l.created_at).toLocaleString()}</small>
        `;
        box.appendChild(div);
      });
    })
    .catch(err => {
      if (box) box.innerHTML = '<div class="muted">Error loading audit logs.</div>';
      log("Error loading audit logs: " + err);
    });
}



function applyAuditFilters(){
  const filters = {
    admin_id: document.getElementById('flt-admin').value || "",
    action: document.getElementById('flt-action').value || "",
    ip: document.getElementById('flt-ip').value || "",
    search: document.getElementById('flt-search').value || "",
    start: document.getElementById('flt-date-start').value || "",
    end: document.getElementById('flt-date-end').value || ""
  };
  loadAuditLogs(filters);
}

function resetAuditFilters(){
  document.querySelectorAll('.audit-filter-box .flt').forEach(i=>i.value="");
  loadAuditLogs();
}



function exportAuditCSV(){
  const filters = {
    admin_id: document.getElementById('flt-admin').value || "",
    action: document.getElementById('flt-action').value || "",
    ip: document.getElementById('flt-ip').value || "",
    search: document.getElementById('flt-search').value || "",
    start: document.getElementById('flt-date-start').value || "",
    end: document.getElementById('flt-date-end').value || ""
  };
  const query = new URLSearchParams(filters).toString();
  safeFetch('/api/admin/audit_logs?' + query)
    .then(r => r.json())
    .then(rows => {
      if (!rows.length){
        alert("No logs to export.");
        return;
      }
      let csv = "ID,Admin ID,Action,Details,IP,Timestamp\n";
      rows.forEach(l => {
        csv += `"${l.id}","${l.admin_id}","${l.action}","${(l.details||"").replace(/"/g,'""')}","${l.ip}","${l.created_at}"\n`;
      });
      const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "audit_logs_export.csv";
      a.click();
      URL.revokeObjectURL(url);
    });
}


document.addEventListener("DOMContentLoaded", () => {
  loadAuditLogs();
  if (!AUDIT_CSV_AUTO_DONE) { AUDIT_CSV_AUTO_DONE = true; exportAuditCSV(); }
  loadApiBase();
  document.getElementById("api-save").addEventListener("click", saveApiBase);
  const battleBtn = document.getElementById("battle-run");
  if (battleBtn) battleBtn.addEventListener("click", runBattle);
  refreshAll();
  setInterval(loadTipStream,3000);
  document.getElementById("tp-send").addEventListener("click", sendTip);
  document.getElementById("tp-close").addEventListener("click", closeTipPopup);
  attachTipPresets();
  setTimeout(attachMiniProfileEvents,500);
});
