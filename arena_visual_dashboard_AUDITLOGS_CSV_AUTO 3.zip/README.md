# 📘 Arena Visual Dashboard – Admin 2FA Edition  
**Production-ready admin panel for ScrollX / Matty BTC Arena**

This dashboard provides a fully secure, visual, analytics-heavy control panel for the ScrollX BTC arena system.  
It includes full administrator authentication with **username + password + TOTP-based 2FA**, live BTC streams, leaderboards, battles, tier presets, creator analytics, and admin-only access.

---

# 🚀 Features

### 🔐 **Full Admin Security Stack**
- Admin login (`admin-login.html`)
- Username + password + 6-digit TOTP (Google Authenticator)
- JWT-like admin token stored locally
- Every dashboard request includes `X-Admin-Token`
- Dashboard blocks access unless token is valid

### 🔑 **Admin 2FA Setup Flow**
File: `admin-2fa-setup.html`

Admin enters their ID, receives:

- Base32 TOTP secret  
- QR code for Google Authenticator / Authy  
- otpauth:// URL  
- Field to submit verification code  

Once verified, backend marks admin’s 2FA as enabled.

---

# 🎛 Dashboard Tools (index.html + app.js)

### 🪙 **Tip Stream (Live)**
Real-time BTC tips, sorted and animated.

### ⚔️ **Battle Mode**
Compare 2 creators head-to-head (BTC totals, streaks, ranks).

### ⭐ **Tier-Based Presets**
Bronze / Silver / Gold / Diamond preset structures auto-loaded per creator.

### 🎨 **Tip Animation Engine**
- BTC coin float  
- Gold spark burst  
- Raising BTC text  
- Pulse glow  

Triggered on every successful tip.

### 🧩 **Mini Profiles**
Hover cards with avatar, BTC totals, streak, rank.

### 📊 **Daily Charts**
BTC Today vs Yesterday  
Daily Logs  
Creator Rankings  
Arena Stats  

### 🔥 **Streak Leaderboard**
Sorted list of top streaks for all creators.

---

# 📂 File Structure

```
/
├── index.html
├── admin-login.html
├── admin-2fa-setup.html
├── app.js
├── style.css
└── module.json
```

---

# ⚙ Backend Requirements (Flask)

### User model:
```python
is_admin = db.Column(db.Boolean, default=False)
admin_token = db.Column(db.String(128))
twofa_secret = db.Column(db.String(64))
twofa_enabled = db.Column(db.Boolean, default=False)
```

### Install libraries:
```
pip install pyotp qrcode[pil]
```

### Required Endpoints:
```
POST /api/admin/login
GET  /api/admin/setup_2fa/<user_id>
POST /api/admin/verify_2fa
```

### Dashboard Endpoints (protected)
```
GET /api/arena/tip_stream
GET /api/arena/top_streaks
GET /api/arena/battle/<id1>/<id2>
GET /api/arena/tip_presets/<id>
GET /api/arena/profile_mini/<id>
GET /api/leaderboard
GET /api/arena/stats/me
GET /api/arena/btc/today_yesterday
GET /api/arena/daily
```

All must validate token from:
```
X-Admin-Token
```

---

# 🛠 Admin 2FA Setup Example (Backend)

### Generate secret + QR
```
GET /api/admin/setup_2fa/<id>
```

### Verify and enable
```
POST /api/admin/verify_2fa
{
  "user_id": 1,
  "code": "123456"
}
```

---

# 🧪 Testing Steps

1. Open `/admin-2fa-setup.html`
2. Generate QR → Scan with Google Authenticator
3. Enter the 6-digit code → Verify
4. Go to `/admin-login.html`
5. Log in with username + password + 2FA code
6. Dashboard loads when token is valid

---

# 📦 Build Notes

- Works on Netlify  
- Works inside ScrollX Launcher (Electron EXE)  
- Works with local Flask hosts  
- Requires HTTPS in production for 2FA  

---

# ✨ Credits
Built for the ScrollX / Matty ecosystem.  
Optimized for performance, security, and real-time interactivity.