Matty V4 – full static site QR gallery with Netlify config.
Deploy by pointing Netlify publish dir to ./site.
